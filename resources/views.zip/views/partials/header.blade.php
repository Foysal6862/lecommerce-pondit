<div class="header">

    <div class="container">

        @include('partials.logo')
        @include('partials.header-top')
        @include('partials.header-social-icons')
        @include('partials.nav-top')

    </div>
</div>
