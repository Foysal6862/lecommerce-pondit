<div class="logo">
    <h1 ><a href="{{ url('') }}"><b>T<br>H<br>E</b>Big Store<span>The Best Supermarket</span></a></h1>
</div>